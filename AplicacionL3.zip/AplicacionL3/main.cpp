#include "Aplicacion.h"
#include <iostream>
#include <string.h>// libreria para la clase string
#include <fstream>// libreria para el manejo de archivos
#include <sstream>

using namespace std;

int main(){
    while (true) {
        char opcion='0';
        cout<<"Bienvenido al cajero"<<endl<<endl;
        cout<<"Ingrese:"<<endl<<endl;
        cout<<"1.Entrar como administrador"<<endl<<"2.Entrar como usuario"<<endl<<"3.Salir"<<endl<<endl;
        cout<<"Escriba la operacion a realizar: ";
        cin>>opcion;
        if(opcion=='1')MenuAdmin();//operaciones de administrador

        else if(opcion=='2'){//operaciones de usuario
            cout<<endl<<"Ha ingresado como usuario"<<endl<<endl;
            opcion='0';
        while(opcion!='3'){// opcion de salida
            cout<<"Ingrese:"<<endl<<endl;
            cout<<"1.Consultar saldo"<<endl<<"2.Retirar dinero"<<endl<<"3.Salir"<<endl<<endl;
            cout<<"Cada operacion tiene un costo de $1000"<<endl<<endl;
            cout<<"Escriba la operacion a realizar:";
            cin>>opcion;
            if(opcion=='1'){//consultar estado de la cuenta
                string claveusu;
                cout<<endl<<"Porfavor ingrese su clave: ";
                cin>>claveusu;
                bool ayuda=false;
                while(ayuda==false){
                    if(Validarnumeros(claveusu)==false){
                        cout<<endl<<"Por favor digite solo caracteres numericos"<<endl;
                        cout<<endl<<"Porfavor ingrese su clave: ";
                        cin>>claveusu;
                    }
                    else if(claveusu.length()!=4){
                        cout<<endl<<"Por favor solo digite 4 digitos"<<endl;
                        cout<<endl<<"Porfavor ingrese su clave: ";
                        cin>>claveusu;
                    }
                    else ayuda=true;
                }
                Infousuarios(claveusu);
            }
            else if(opcion=='2'){//retirar dinero
                string claveusu2;
                bool ayuda=false;
                cout<<endl<<"Porfavor ingrese su clave: ";
                cin>>claveusu2;
                while(ayuda==false){
                    if(Validarnumeros(claveusu2)==false){
                        cout<<endl<<"Por favor digite solo caracteres numericos"<<endl;
                        cout<<endl<<"Porfavor ingrese su clave: ";
                        cin>>claveusu2;
                    }
                    else if(claveusu2.length()!=4){
                        cout<<endl<<"Por favor solo digite 4 digitos"<<endl;
                        cout<<endl<<"Porfavor ingrese su clave:";
                        cin>>claveusu2;
                    }
                    else ayuda=true;
                }
                Retirardinero(claveusu2);
            }
            else if(opcion=='3')cout<<endl;//salir del modo de usuario

            else cout<<endl<<"Operacion incorrecta, intenta nuevamente"<<endl;// en caso de no ser ninguna de las opciones
        }
        opcion='0';
       }
      else cout<<"Hasta luego."<<endl; break;
    }
    return 0;
}
