#ifndef APLICACION_H
#define APLICACION_H

#include <iostream>
#include <string.h>
#include <fstream>

using namespace std;
//-------C y D-----------------

string Encriptacion_c(string,unsigned int);
string Stringabinario(string);
string Desplazarbits(string );
unsigned int SiguienteMultiplo(int _num,int _len);
string Desencriptacion();// aplica el segundo metodo de desencriptacion
string Desplazarbits2(string binario);
string Numericoastring(int);
//-----------------------------------


void MenuAdmin();// realiza las operaciones del administrador
bool ValidacionClave(string,string);// mira si la clave ingresada es correcta
void Escribirarchivo(string,string);//escribe el archivo con la informacion de los usarios
string Leerarchivo(string);//extrae la informacion del archivo ingresado
bool Validarnumeros(string);//Valida si los caracteres ingresados son numericos
void Infousuarios(string);// muestra al usuario su informacion de su saldo
void Retirardinero(string);//realiza la segunda funcion del usuario
void Infousuarios(string);
void Renombrararchivo();
void Eliminararchivo();

#endif // APLICACION_H
